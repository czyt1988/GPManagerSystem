#include "FCNodeGraphicsFactory.h"
#include "FCConstValueNodeGraphicsItem.h"
FCNodeGraphicsFactory::FCNodeGraphicsFactory()
{
    m_prototypes<<"FC.Util.Const";

    m_prototypesGroup['common'] << "FC.Util.Const";
}

QString FCNodeGraphicsFactory::factoryName() const
{
    return "FC.Util";
}

FCAbstractNodeGraphicsItem *FCNodeGraphicsFactory::create(const QString &prototype)
{
    if(prototype == "FC.Util.Const"){
        return new FCConstValueNodeGraphicsItem();
    }
    return nullptr;
}

QStringList FCNodeGraphicsFactory::getPrototypes() const
{
    return m_prototypes;
}

QHash<QString, QStringList> FCNodeGraphicsFactory::getPrototypesGroup() const
{
    return m_prototypesGroup;
}

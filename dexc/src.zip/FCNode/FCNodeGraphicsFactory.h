#ifndef FCNODEGRAPHICSFACTORY_H
#define FCNODEGRAPHICSFACTORY_H
#include "FCNodeGlobal.h"
#include "FCAbstractNodeGraphicsFactory.h"
/**
 * @brief 主节点工厂
 */
class FCNodeGraphicsFactory : public FCAbstractNodeGraphicsFactory
{
public:
    FCNodeGraphicsFactory();

    //工厂名称
    virtual QString factoryName() const;

    //工厂函数，创建一个FCNodeGraphicsItem，工厂不持有FCNodeGraphicsItem的管理权
    virtual FCAbstractNodeGraphicsItem *create(const QString& prototype);

    //获取所有注册的Prototypes
    virtual QStringList getPrototypes() const;

    //获取所有类型的分组，同样的分组会放置在一起，这样一个工厂不仅仅只对应一个分组
    virtual QHash<QString, QStringList> getPrototypesGroup() const;
private:
    QStringList m_prototypes;
    QHash<QString, QStringList> m_prototypesGroup;
};

#endif // FCNODEGRAPHICSFACTORY_H

#include "FCAbstractNodeGraphicsFactory.h"

FCAbstractNodeGraphicsFactory::FCAbstractNodeGraphicsFactory()
{

}

FCAbstractNodeGraphicsFactory::~FCAbstractNodeGraphicsFactory()
{

}

﻿#include "FCAbstractNodeGraphicsItem.h"

class FCAbstractNodeGraphicsItemPrivate {
    FC_IMPL_PUBLIC(FCAbstractNodeGraphicsItem)
public:
    FCAbstractNodeGraphicsItemPrivate(FCAbstractNodeGraphicsItem *p);
    QString _name;
};

FCAbstractNodeGraphicsItemPrivate::FCAbstractNodeGraphicsItemPrivate(FCAbstractNodeGraphicsItem *p)
    : q_ptr(p)
{
}


FCAbstractNodeGraphicsItem::FCAbstractNodeGraphicsItem(QGraphicsItem *p) : QGraphicsItem(p)
    , d_ptr(new FCAbstractNodeGraphicsItemPrivate(this))
{
}


FCAbstractNodeGraphicsItem::~FCAbstractNodeGraphicsItem()
{
}


QString FCAbstractNodeGraphicsItem::getNodeName() const
{
    return (d_ptr->_name);
}


void FCAbstractNodeGraphicsItem::setNodeName(const QString& name)
{
    d_ptr->_name = name;
}


QString FCAbstractNodeGraphicsItem::getNodePrototype() const
{
    return ("FC.FCNodeGraphicsItem");
}

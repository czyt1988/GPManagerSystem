﻿#ifndef FCD3VIEWERAPI_H
#define FCD3VIEWERAPI_H

#include <QtCore/QtGlobal>


#if defined(FCD3VIEWER_BUILDLIB)
#define FCD3VIEWER_API    Q_DECL_EXPORT
#else
#define  FCD3VIEWER_API
#endif

//Q_DECL_IMPORT.
#endif

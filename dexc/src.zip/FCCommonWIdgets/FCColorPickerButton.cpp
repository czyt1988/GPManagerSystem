﻿#include "FCColorPickerButton.h"

FCColorPickerButton::FCColorPickerButton(QWidget *parent)
    :ctkColorPickerButton(parent)
{

}

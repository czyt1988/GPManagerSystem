﻿#include "FCCoordinatesWidget.h"

FCCoordinatesWidget::FCCoordinatesWidget(QWidget *p) : ctkCoordinatesWidget(p)
{
}

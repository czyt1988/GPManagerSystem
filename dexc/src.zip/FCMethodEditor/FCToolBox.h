﻿#ifndef FCTOOLBOX_H
#define FCTOOLBOX_H
#include <QToolBox>

class FCToolBox : public QToolBox
{
    Q_OBJECT
public:
    FCToolBox() = default;
};

#endif // FCTOOLBOX_H

#include "FCMimeData.h"

FCMimeData::FCMimeData() : QMimeData()
{

}
